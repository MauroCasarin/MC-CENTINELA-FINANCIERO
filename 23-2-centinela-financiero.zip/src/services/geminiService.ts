import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

export interface MarketAlert {
  assetName: string;
  verdict: 'ENTRAR' | 'SALIR' | 'MANTENER';
  confidence: number;
  reliability: 'BAJA' | 'MEDIA' | 'ALTA';
  sources: string[];
  sourcesAnalyzedCount: number;
  dataCrossAnalysis: string;
  recommendedAction: string;
  stopLoss: string;
  timeframe: 'Corto' | 'Medio' | 'Largo';
}

export interface MarketStatus {
  alerts: MarketAlert[];
  isCalm: boolean;
  sourcesAnalyzedCount: number;
  timestamp: string;
}

const SYSTEM_INSTRUCTION = `Eres "CENTINELA FINANCIERO v5.5", un motor de búsqueda y análisis financiero de grado institucional. Tu función es el análisis proactivo de mercados y la asistencia técnica modular.

### REGLAS DE DESARROLLO (ESTRICTAS):
1. NO USE FRAMEWORKS: Está terminantemente prohibido usar React, Vite, Tailwind o archivos .tsx. Genera siempre HTML, CSS y JS nativo en un único bloque de código.
2. COMPATIBILIDAD: Todo código debe ser 100% responsivo, optimizado para celulares y computadoras mediante meta-tags de viewport.
3. IDENTIDAD VISUAL: 
   - Logo: https://avatars.githubusercontent.com/u/70527971?s=48&v=4
   - Link: https://www.instagram.com/3d_mc_3d/
4. RESPUESTA MODULAR: Si el usuario pide un cambio estético o una nueva alerta, NO reescribas el index.html completo. Entrega solo el fragmento de código (HTML o CSS) con instrucciones de dónde pegarlo dentro del archivo principal.

### PROTOCOLO DE ANÁLISIS:
- Realiza búsquedas en tiempo real utilizando la herramienta googleSearch.
- Formato de alerta: Título del activo, Veredicto (ENTRAR/SALIR/ESPERAR), Confianza (x/10), Auditoría (mínimo 10 fuentes) y un resumen técnico breve.

IMPORTANTE: Siempre usa la herramienta googleSearch para obtener datos actualizados de hoy.`;

export async function performMarketScan(): Promise<MarketStatus> {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  
  const prompt = `Realiza una auditoría y escaneo completo del mercado argentino y global hoy (${new Date().toLocaleDateString()}). 
  Busca oportunidades críticas en Acciones, Bonos, Letras, CEDEARs, Cripto y Dólar.
  
  Responde estrictamente en formato JSON con la siguiente estructura:
  {
    "alerts": [
      {
        "assetName": "Nombre del Activo",
        "verdict": "ENTRAR/SALIR/MANTENER",
        "confidence": 1-10,
        "reliability": "BAJA/MEDIA/ALTA",
        "sources": ["Fuente 1", "Fuente 2", "Fuente 3"],
        "sourcesAnalyzedCount": número total de fuentes rastreadas para este activo,
        "dataCrossAnalysis": "Conclusión del análisis masivo: qué dicen la mayoría de los sitios vs. los datos de precio",
        "recommendedAction": "Instrucción directa de qué hacer",
        "stopLoss": "Precio de venta de emergencia",
        "timeframe": "Corto/Medio/Largo"
      }
    ],
    "isCalm": boolean (true si no hay alertas significativas),
    "sourcesAnalyzedCount": número total de fuentes rastreadas en todo el ecosistema digital durante este escaneo
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        tools: [{ googleSearch: {} }]
      },
    });

    const result = JSON.parse(response.text || '{}');
    return {
      alerts: result.alerts || [],
      isCalm: result.isCalm ?? (result.alerts?.length === 0),
      sourcesAnalyzedCount: result.sourcesAnalyzedCount || 0,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error("Error in market scan:", error);
    throw error;
  }
}
