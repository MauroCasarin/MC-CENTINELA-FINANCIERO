export const DICCIONARIO_FINANCIERO: Record<string, string> = {
  "Brecha": "Es la distancia que hay entre el dólar 'oficial' y los dólares libres como el MEP o el Blue. Cuanto más grande es, más distorsionada está la economía.",
  "Riesgo País": "Es un indicador que mide el 'miedo' que tienen afuera de prestarnos plata. Cuanto más alto es el número, menos confianza nos tienen y más riesgo ven de que Argentina no pague sus deudas.",
  "Carry Trade": "Es el famoso 'bicicleteo'. Vendes tus dólares, ponés los pesos a rendir en una tasa alta y, antes de que el dólar suba, volvés a comprar los verdes. Si sale bien, terminás con más dólares que al principio.",
  "IPC": "Es el número oficial que dice cuánto subieron los precios en promedio. Es tu punto de comparación: si tus ahorros no rinden más que el IPC, estás perdiendo contra el súper.",
  "Inflación": "Es el aumento generalizado y sostenido de los precios de los bienes y servicios existentes en el mercado durante un período de tiempo.",
  "Arbitraje": "En la jerga es 'hacer el rulo'. Es comprar algo donde está barato y venderlo donde está más caro en el mismo momento para ganarte la diferencia.",
  "Tasa Real": "Es la ganancia 'limpia' después de restar la inflación. El REM es la encuesta que hace el Banco Central para saber qué inflación esperan los expertos para los meses que vienen.",
  "REM": "Relevamiento de Expectativas de Mercado. Es la encuesta que hace el Banco Central para saber qué inflación esperan los expertos para los meses que vienen.",
  "Tipo de Cambio Real": "Compara el valor del dólar contra la inflación. Te dice si el dólar se quedó 'atrasado' o 'barato' respecto a cómo subió todo lo demás.",
  "Pasivos Remunerados": "Es la guita que el Banco Central le debe a los bancos para que esos pesos no estén dando vueltas en la calle. Es como una 'aspiradora' de pesos que usa el Gobierno para que no se vayan al dólar ni generen más inflación.",
  "Liquidez": "Es la velocidad con la que podés transformar tu inversión en efectivo sin perder plata.",
  "Fondos Comunes": "Es 'hacer una vaquita' con otros inversores para que un profesional maneje la plata. Los de las billeteras virtuales (Mercado Pago, Ualá) son los más conocidos.",
  "FCI": "Fondos Comunes de Inversión. Es 'hacer una vaquita' con otros inversores para que un profesional maneje la plata.",
  "Cauciones": "Es el 'plazo fijo' de la bolsa. Podés prestar tu plata desde 1 día en adelante. Es de lo más seguro que existe en el mercado.",
  "Lecaps": "Son promesas de pago del Gobierno a corto plazo. Le prestás al Estado por unos meses a cambio de un interés que suele ganarle al plazo fijo común.",
  "Letras": "Títulos de deuda a corto plazo emitidos por el Tesoro Nacional.",
  "Licitaciones": "Es cuando el Gobierno o una empresa sacan un bono nuevo 'directo de fábrica'. Te anotás para comprar antes que el resto.",
  "Dólar Cripto": "Comprar monedas digitales que valen siempre 1 dólar (como USDT). Es el único mercado que no cierra nunca, funcionando las 24 horas, los 365 días del año.",
  "Parking": "Es el tiempo obligatorio que tenés que 'quedarte quieto' con un bono en la mano antes de poder venderlo para recibir dólares (Dólar MEP).",
  "Obligaciones Negociables": "Le prestás plata a empresas grandes (YPF, Pampa, IRSA). Te pagan intereses y te devuelven el capital, generalmente en dólares billete.",
  "ON": "Obligaciones Negociables. Títulos de deuda emitidos por empresas privadas.",
  "CEDEARs": "Son 'pedacitos' de empresas de afuera (Apple, Google, Coca-Cola) que comprás acá con pesos. Te cubren si el dólar suba.",
  "Acciones": "Sos socio de empresas. Es una inversión emocionante porque si al país le va bien pueden subir mucho, pero son muy volátiles.",
  "Bonos": "Títulos de deuda del Estado a largo plazo. Su precio depende totalmente de la confianza que el mundo le tenga al país para pagar sus deudas.",
  "Futuros": "Es como 'congelar' el precio de algo hoy para pagarlo o venderlo más adelante.",
  "Opciones": "Contratos que dan el derecho, pero no la obligación, de comprar o vender un activo a un precio determinado.",
  "Stop Loss": "Es una orden automática que le das a tu broker para que venda tu inversión si el precio cae hasta cierto punto."
};

export const loadingMessages = [
  "Analizando el mercado...",
  "Consultando fuentes financieras...",
  "Calculando proyecciones...",
  "Preparando el informe...",
  "Casi listo..."
];
