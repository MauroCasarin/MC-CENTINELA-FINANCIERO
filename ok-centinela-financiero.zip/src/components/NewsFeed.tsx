import { useState, useEffect, useRef, RefObject } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Loader2, AlertCircle, Newspaper, ChevronRight, ChevronLeft, TrendingUp, Brain, Sparkles, RefreshCw } from 'lucide-react';
import { NewsItem } from '../types';

const API_URL = "https://script.google.com/macros/s/AKfycbyRzAtQjhLexPaatkpxGCgq6dfLzp7R6-xO0zvComD3gg1CJbODXaZdqUe5GX9zi0lP4A/exec";
const DOLAR_API_URL = "https://dolarapi.com/v1/dolares/oficial";
const DOLAR_BLUE_API_URL = "https://dolarapi.com/v1/dolares/blue";
const DOLAR_MEP_API_URL = "https://dolarapi.com/v1/dolares/bolsa";
const DOLAR_CCL_API_URL = "https://dolarapi.com/v1/dolares/contadoconliqui";
const DOLAR_MAYORISTA_API_URL = "https://dolarapi.com/v1/dolares/mayorista";
const DOLAR_CRIPTO_API_URL = "https://dolarapi.com/v1/dolares/cripto";
const RIESGO_PAIS_API_URL = "https://api.argentinadatos.com/v1/finanzas/indices/riesgo-pais";
const INFLACION_API_URL = "https://api.argentinadatos.com/v1/finanzas/indices/inflacion";
const PLAZO_FIJO_API_URL = "https://api.argentinadatos.com/v1/finanzas/tasas/plazoFijo";
const BILLETERAS_FCI_ULTIMO = "https://api.argentinadatos.com/v1/finanzas/fci/mercadoDinero/ultimo";
const BILLETERAS_FCI_PENULTIMO = "https://api.argentinadatos.com/v1/finanzas/fci/mercadoDinero/penultimo";
const BILLETERAS_RENDIMIENTOS = "https://api.argentinadatos.com/v1/finanzas/rendimientos";

export default function NewsFeed() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [dolar, setDolar] = useState<{compra: number, venta: number} | null>(null);
  const [dolarBlue, setDolarBlue] = useState<{compra: number, venta: number} | null>(null);
  const [dolarMep, setDolarMep] = useState<{compra: number, venta: number} | null>(null);
  const [dolarCcl, setDolarCcl] = useState<{compra: number, venta: number} | null>(null);
  const [dolarMayorista, setDolarMayorista] = useState<{compra: number, venta: number} | null>(null);
  const [dolarCripto, setDolarCripto] = useState<{compra: number, venta: number} | null>(null);
  const [riesgoPais, setRiesgoPais] = useState<{valor: number, fecha: string} | null>(null);
  const [inflacion, setInflacion] = useState<{valor: number, fecha: string} | null>(null);
  const [plazosFijos, setPlazosFijos] = useState<any[]>([]);
  const [billeteras, setBilleteras] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const generateAIAnalysis = async (currentData: any) => {
    setIsAnalyzing(true);
    try {
      const prompt = `
        Actúa como un analista financiero experto en el mercado argentino. 
        Analiza los siguientes datos actuales y proporciona una estrategia de inversión concisa, 
        recomendaciones claras y un panorama general. Cruza la información de mercado, rendimientos y noticias.

        DATOS DE MERCADO:
        - Dólar Oficial: $${currentData.dolar?.venta || 'N/A'}
        - Dólar Blue: $${currentData.dolarBlue?.venta || 'N/A'}
        - Dólar MEP: $${currentData.dolarMep?.venta || 'N/A'}
        - Dólar CCL: $${currentData.dolarCcl?.venta || 'N/A'}
        - Riesgo País: ${currentData.riesgoPais?.valor || 'N/A'}
        - Inflación (IPC mensual): ${currentData.inflacion?.valor || 'N/A'}%

        RENDIMIENTOS (TNA):
        - Plazos Fijos (Top): ${currentData.plazosFijos?.map((f: any) => `${f.entidad}: ${(f.tna * 100).toFixed(1)}%`).join(', ') || 'N/A'}
        - Billeteras (Top): ${currentData.billeteras?.map((b: any) => `${b.entidad}: ${b.tna}%`).join(', ') || 'N/A'}

        NOTICIAS RECIENTES:
        ${currentData.news?.slice(0, 10).map((n: any) => `- ${n.titulo || n.title}`).join('\n')}

        INSTRUCCIONES DE FORMATO:
        1. Sé directo y profesional.
        2. Usa viñetas para las recomendaciones.
        3. Concluye con una "Estrategia Sugerida" de una oración.
        4. No uses introducciones largas.
        5. Máximo 200 palabras.
      `;

      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Error en el servidor");
      }

      const result = await response.json();
      setAiAnalysis(result.text || "No se pudo generar el análisis en este momento.");
    } catch (err: any) {
      console.error("AI Analysis Error:", err);
      setAiAnalysis(`Error: ${err.message || "Error al conectar con el servidor."}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const cleanEntityName = (name: string) => {
    if (!name) return '';
    
    // 1. Fix common encoding issues (UTF-8 bytes interpreted as Latin-1)
    let fixed = name
      .replace(/Ã\u008D/g, 'Í')
      .replace(/Ã\u0091/g, 'Ñ')
      .replace(/Ã\u0093/g, 'Ó')
      .replace(/Ã\u0081/g, 'Á')
      .replace(/Ã\u0089/g, 'É')
      .replace(/Ã\u009A/g, 'Ú')
      .replace(/Ã\u00AD/g, 'í')
      .replace(/Ã±/g, 'ñ')
      .replace(/Ã³/g, 'ó')
      .replace(/Ã¡/g, 'á')
      .replace(/Ã©/g, 'é')
      .replace(/Ãº/g, 'ú')
      .replace(/CRÃDITO/gi, 'CRÉDITO') // Specific fix for user's example
      .replace(/Ã/g, 'Ñ'); // Catch-all for remaining Ã (often Ñ)

    // 2. Shorten and clean
    let cleaned = fixed
      .replace(/COMPAÑIA FINANCIERA/gi, '')
      .replace(/COMPAÑÍA FINANCIERA/gi, '')
      .replace(/S\.A\.U\./gi, '')
      .replace(/S\.A\./gi, '')
      .replace(/S\.A/gi, '')
      .replace(/BANCO/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    // 3. Title Case
    cleaned = cleaned.toLowerCase().split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');

    // 4. Specific manual overrides for better display
    if (cleaned.includes('Credito Regional')) return 'Crédito Regional';
    if (cleaned.includes('Reba')) return 'Reba';
    if (cleaned.includes('Galicia')) return 'Galicia';
    if (normalizedIncludes(cleaned, 'Delsol')) return 'Banco del Sol';
    
    return cleaned;
  };

  const normalizedIncludes = (str: string, search: string) => 
    str.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .includes(search.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""));

  const getEntityUrl = (name: string) => {
    const normalized = name.toLowerCase();
    // Billeteras
    if (normalizedIncludes(name, 'mercado pago')) return 'https://www.mercadopago.com.ar';
    if (normalizedIncludes(name, 'uala')) return 'https://www.uala.com.ar';
    if (normalizedIncludes(name, 'personal pay')) return 'https://www.personalpay.com.ar';
    if (normalizedIncludes(name, 'naranja')) return 'https://www.naranjax.com';
    if (normalizedIncludes(name, 'prex')) return 'https://www.prexcard.com.ar';
    if (normalizedIncludes(name, 'fiwind')) return 'https://www.fiwind.io';
    if (normalizedIncludes(name, 'belo')) return 'https://www.belo.app';
    if (normalizedIncludes(name, 'lemon')) return 'https://www.lemon.me';
    if (normalizedIncludes(name, 'letsbit')) return 'https://letsbit.io';
    if (normalizedIncludes(name, 'buenbit')) return 'https://www.buenbit.com';
    if (normalizedIncludes(name, 'reba')) return 'https://www.reba.com.ar';
    
    // Bancos
    if (normalizedIncludes(name, 'galicia')) return 'https://www.galicia.ar';
    if (normalizedIncludes(name, 'santander')) return 'https://www.santander.com.ar';
    if (normalizedIncludes(name, 'bbva') || normalizedIncludes(name, 'frances')) return 'https://www.bbva.com.ar';
    if (normalizedIncludes(name, 'nacion')) return 'https://www.bna.com.ar';
    if (normalizedIncludes(name, 'macro')) return 'https://www.macro.com.ar';
    if (normalizedIncludes(name, 'hsbc')) return 'https://www.hsbc.com.ar';
    if (normalizedIncludes(name, 'icbc')) return 'https://www.icbc.com.ar';
    if (normalizedIncludes(name, 'ciudad')) return 'https://www.bancociudad.com.ar';
    if (normalizedIncludes(name, 'provincia')) return 'https://www.bancoprovincia.com.ar';
    if (normalizedIncludes(name, 'supervielle')) return 'https://www.supervielle.com.ar';
    if (normalizedIncludes(name, 'hipotecario')) return 'https://www.hipotecario.com.ar';
    if (normalizedIncludes(name, 'patagonia')) return 'https://www.bancopatagonia.com.ar';
    if (normalizedIncludes(name, 'comafi')) return 'https://www.comafi.com.ar';
    if (normalizedIncludes(name, 'credicoop')) return 'https://www.bancocredicoop.coop';
    if (normalizedIncludes(name, 'bancor') || normalizedIncludes(name, 'cordoba')) return 'https://www.bancor.com.ar';
    if (normalizedIncludes(name, 'banco del sol') || normalizedIncludes(name, 'delsol')) return 'https://www.bancodelsol.com';
    if (normalizedIncludes(name, 'bica')) return 'https://www.bancobica.com.ar';
    if (normalizedIncludes(name, 'cmf')) return 'https://www.bancocmf.com.ar';
    if (normalizedIncludes(name, 'meridian')) return 'https://www.bancomeridian.com.ar';
    if (normalizedIncludes(name, 'voii')) return 'https://www.voii.com.ar';
    if (normalizedIncludes(name, 'chubut')) return 'https://www.bancochubut.com.ar';
    if (normalizedIncludes(name, 'santa fe')) return 'https://www.bancosantafe.com.ar';
    if (normalizedIncludes(name, 'entre rios')) return 'https://www.bancoentrerios.com.ar';
    if (normalizedIncludes(name, 'san juan')) return 'https://www.bancosanjuan.com';
    if (normalizedIncludes(name, 'santa cruz')) return 'https://www.bancosantacruz.com';
    if (normalizedIncludes(name, 'industrial') || normalizedIncludes(name, 'bind')) return 'https://www.bind.com.ar';
    if (normalizedIncludes(name, 'piano')) return 'https://www.bancopiano.com.ar';
    if (normalizedIncludes(name, 'roela')) return 'https://www.bancoroela.com.ar';
    if (normalizedIncludes(name, 'saenz')) return 'https://www.bancosaenz.com.ar';
    if (normalizedIncludes(name, 'columbia')) return 'https://www.bancocolumbia.com.ar';
    if (normalizedIncludes(name, 'credito regional')) return 'https://www.creditoregional.com.ar/CRInstitucional/inicio';
    
    return '#';
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch News
        const newsResponse = await fetch(API_URL);
        if (!newsResponse.ok) throw new Error(`Failed to fetch news: ${newsResponse.statusText}`);
        const newsData = await newsResponse.json();
        
        // Process News Data
        let items: NewsItem[] = [];
        if (newsData.noticias && Array.isArray(newsData.noticias)) {
          items = newsData.noticias;
        } else if (Array.isArray(newsData)) {
          items = newsData;
        } else if (newsData && typeof newsData === 'object') {
          if (Array.isArray(newsData.data)) items = newsData.data;
          else if (Array.isArray(newsData.items)) items = newsData.items;
          else if (Array.isArray(newsData.news)) items = newsData.news;
          else items = [newsData];
        }

        // Deduplicate items
        const uniqueItems: NewsItem[] = [];
        const seenTitles = new Set<string>();
        for (const item of items) {
           const title = item.titulo || item.title || item.headline;
           const normalizedTitle = String(title || '').trim().toLowerCase();
           if (normalizedTitle && !seenTitles.has(normalizedTitle)) {
             seenTitles.add(normalizedTitle);
             uniqueItems.push(item);
           }
        }
        setNews(uniqueItems);

        // Fetch Financial Data (Non-blocking)
        const fetchJsonSafe = async (url: string) => {
            try {
                const res = await fetch(url);
                if (!res.ok) return null;
                return await res.json();
            } catch (e) {
                console.warn(`Error fetching ${url}:`, e);
                return null;
            }
        };

        try {
            const [oficial, blue, mep, ccl, mayorista, cripto, riesgo, inflacion, pf, fciUltimo, fciPenultimo, rendimientos] = await Promise.all([
                fetchJsonSafe(DOLAR_API_URL),
                fetchJsonSafe(DOLAR_BLUE_API_URL),
                fetchJsonSafe(DOLAR_MEP_API_URL),
                fetchJsonSafe(DOLAR_CCL_API_URL),
                fetchJsonSafe(DOLAR_MAYORISTA_API_URL),
                fetchJsonSafe(DOLAR_CRIPTO_API_URL),
                fetchJsonSafe(RIESGO_PAIS_API_URL),
                fetchJsonSafe(INFLACION_API_URL),
                fetchJsonSafe(PLAZO_FIJO_API_URL),
                fetchJsonSafe(BILLETERAS_FCI_ULTIMO),
                fetchJsonSafe(BILLETERAS_FCI_PENULTIMO),
                fetchJsonSafe(BILLETERAS_RENDIMIENTOS)
            ]);

            if (oficial) setDolar(oficial);
            if (blue) setDolarBlue(blue);
            if (mep) setDolarMep(mep);
            if (ccl) setDolarCcl(ccl);
            if (mayorista) setDolarMayorista(mayorista);
            if (cripto) setDolarCripto(cripto);
            
            if (riesgo) {
                const lastValue = Array.isArray(riesgo) ? riesgo[riesgo.length - 1] : null;
                setRiesgoPais(lastValue);
            }
            
            if (inflacion) {
                const lastValue = Array.isArray(inflacion) ? inflacion[inflacion.length - 1] : null;
                setInflacion(lastValue);
            }
            
            if (pf) {
                // Sort by TNA desc and take top 4
                if (Array.isArray(pf) && pf.length > 0) {
                    const sortedPF = pf
                        .filter((item: any) => item.tnaClientes > 0)
                        .sort((a: any, b: any) => b.tnaClientes - a.tnaClientes)
                        .slice(0, 4)
                        .map((item: any) => ({
                            entidad: item.entidad,
                            tna: item.tnaClientes 
                        }));
                    setPlazosFijos(sortedPF);
                }
            }

            // Client-side Billeteras Calculation
            const fciMapping: Record<string, string> = {
                'Mercado Pago': 'Mercado Fondo - Clase A',
                'Ualá': 'Ualintec Ahorro Pesos - Clase A',
                'Personal Pay': 'Delta Pesos - Clase A',
                'Prex': 'Allaria Ahorro - Clase A',
                'Galicia': 'Fima Premium - Clase A'
            };

            const walletRates: any[] = [];

            if (fciUltimo && fciPenultimo) {
                for (const [walletName, fciName] of Object.entries(fciMapping)) {
                    const ultimo = Array.isArray(fciUltimo) ? fciUltimo.find((f: any) => f.fondo === fciName) : null;
                    const penultimo = Array.isArray(fciPenultimo) ? fciPenultimo.find((f: any) => f.fondo === fciName) : null;

                    if (ultimo && penultimo && ultimo.vcp && penultimo.vcp && ultimo.fecha && penultimo.fecha) {
                        const vcpUltimo = parseFloat(ultimo.vcp);
                        const vcpPenultimo = parseFloat(penultimo.vcp);
                        const diffTime = Math.abs(new Date(ultimo.fecha).getTime() - new Date(penultimo.fecha).getTime());
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
                        const tna = ((vcpUltimo / vcpPenultimo) - 1) * (365 / diffDays) * 100;

                        walletRates.push({
                            entidad: walletName,
                            tna: parseFloat(tna.toFixed(2)),
                            type: 'FCI'
                        });
                    }
                }
            }

            if (Array.isArray(rendimientos)) {
                rendimientos.forEach((entity: any) => {
                    const arsRendimiento = entity.rendimientos.find((r: any) => r.moneda === 'ARS');
                    if (arsRendimiento) {
                        walletRates.push({
                            entidad: entity.entidad.charAt(0).toUpperCase() + entity.entidad.slice(1),
                            tna: parseFloat(arsRendimiento.apy),
                            type: 'Remunerada'
                        });
                    }
                });
            }

            walletRates.sort((a, b) => b.tna - a.tna);
            const topWallets = walletRates.slice(0, 4);
            setBilleteras(topWallets);

            // Trigger AI Analysis
            generateAIAnalysis({
                dolar: oficial,
                dolarBlue: blue,
                dolarMep: mep,
                dolarCcl: ccl,
                riesgoPais: Array.isArray(riesgo) ? riesgo[riesgo.length - 1] : null,
                inflacion: Array.isArray(inflacion) ? inflacion[inflacion.length - 1] : null,
                plazosFijos: pf ? pf.filter((item: any) => item.tnaClientes > 0).sort((a: any, b: any) => b.tnaClientes - a.tnaClientes).slice(0, 4) : [],
                billeteras: topWallets,
                news: items
            });

        } catch (e) {
            console.error("Error fetching financial data:", e);
        }

      } catch (err) {
        console.error("Error fetching data:", err);
        setError(err instanceof Error ? err.message : 'An unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Group news by source
  const groupedNews = news.reduce((acc, item) => {
    let sourceName = item.fuente || item.source || item.sourceName || 'Otras Fuentes';
    if (typeof sourceName === 'object') {
        sourceName = sourceName.name || 'Otras Fuentes';
    }
    // Capitalize first letter just in case
    sourceName = String(sourceName).charAt(0).toUpperCase() + String(sourceName).slice(1);
    
    if (!acc[sourceName]) {
      acc[sourceName] = [];
    }
    acc[sourceName].push(item);
    return acc;
  }, {} as Record<string, NewsItem[]>);

  const pfScrollRef = useRef<HTMLDivElement>(null);
  const billScrollRef = useRef<HTMLDivElement>(null);

  const scroll = (ref: RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
    if (ref.current) {
      const { scrollLeft } = ref.current;
      const scrollTo = direction === 'left' ? scrollLeft - 200 : scrollLeft + 200;
      ref.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-gray-500">
        <Loader2 className="w-8 h-8 animate-spin mb-4" />
        <p>Cargando noticias...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-red-500 p-4 text-center">
        <AlertCircle className="w-10 h-10 mb-4" />
        <h3 className="text-lg font-semibold">Error al cargar noticias</h3>
        <p className="max-w-md mt-2 text-sm opacity-80">{error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-6 px-4 py-2 bg-red-100 text-red-700 rounded-full hover:bg-red-200 transition-colors text-sm font-medium"
        >
          Reintentar
        </button>
      </div>
    );
  }

  if (news.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-gray-500">
        <p>No se encontraron noticias.</p>
      </div>
    );
  }

  return (
    <div className="w-full px-4 py-8 space-y-6">
      
      {/* AI Strategy Container */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full bg-gradient-to-br from-indigo-600 via-blue-700 to-blue-800 rounded-2xl shadow-xl overflow-hidden text-white"
      >
        <div className="px-6 py-4 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-md">
              <Brain className="w-5 h-5 text-indigo-200" />
            </div>
            <div>
              <h2 className="font-bold text-lg tracking-tight flex items-center gap-2">
                Estrategias IA
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              </h2>
              <p className="text-xs text-blue-100/70 font-medium uppercase tracking-wider">Análisis Financiero en Tiempo Real</p>
            </div>
          </div>
          <button 
            onClick={() => generateAIAnalysis({
                dolar, dolarBlue, dolarMep, dolarCcl, riesgoPais, inflacion, plazosFijos, billeteras, news
            })}
            disabled={isAnalyzing}
            className="p-2 hover:bg-white/10 rounded-full transition-colors disabled:opacity-50"
            title="Actualizar análisis"
          >
            <RefreshCw className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="p-6 relative min-h-[120px]">
          {isAnalyzing ? (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <div className="relative">
                <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
                <Brain className="w-6 h-6 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/50" />
              </div>
              <p className="text-sm font-medium text-blue-100 animate-pulse">Cruzando datos y noticias...</p>
            </div>
          ) : aiAnalysis ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="prose prose-invert prose-sm max-w-none"
            >
              <div className="whitespace-pre-wrap text-blue-50 leading-relaxed text-sm font-medium">
                {aiAnalysis}
              </div>
            </motion.div>
          ) : (
            <div className="flex items-center justify-center py-8 text-blue-200/50 italic text-sm">
              Esperando datos para iniciar el análisis...
            </div>
          )}
          
          {/* Decorative elements */}
          <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-white/5 rounded-full blur-3xl"></div>
          <div className="absolute -top-6 -left-6 w-24 h-24 bg-indigo-400/10 rounded-full blur-2xl"></div>
        </div>
      </motion.div>

      {/* Financial Indicators Container */}
      <div className="w-full bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
        <div className="h-9 bg-gray-50 border-b border-gray-200 flex items-center px-4 shrink-0">
           <TrendingUp className="w-4 h-4 text-green-600 mr-2" />
           <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wide">Mercado</h2>
        </div>
        
        <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {dolarMayorista && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-gray-700">MAYORISTA</span>
                    <span>${dolarMayorista.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Comercio Exterior/Importación</span>
               </div>
            )}

            {dolarCcl && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-gray-700">CCL</span>
                    <span>${dolarCcl.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Contado con Liquidación</span>
               </div>
            )}

            {dolarMep && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-orange-500">MEP</span>
                    <span>${dolarMep.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Dólar Bolsa</span>
               </div>
            )}

            {dolarCripto && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-yellow-600">CRIPTO</span>
                    <span>${dolarCripto.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">USDT/USDC 24/7</span>
               </div>
            )}

            {riesgoPais && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-red-600">RIESGO PAÍS</span>
                    <span>{riesgoPais.valor}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Puntos Básicos (JP Morgan)</span>
               </div>
            )}

            {dolar && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-green-600">OFICIAL</span>
                    <span>${dolar.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Banco Nación Venta</span>
               </div>
            )}
            
            {dolarBlue && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-blue-600">BLUE</span>
                    <span>${dolarBlue.venta}</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Mercado Paralelo</span>
               </div>
            )}

            {dolar && dolarBlue && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-purple-600">BRECHA</span>
                    <span>{((dolarBlue.venta - dolar.venta) / dolar.venta * 100).toFixed(1)}%</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Diferencia Blue vs Oficial</span>
               </div>
            )}

            {inflacion && (
               <div className="flex flex-col">
                 <div className="flex items-center gap-1.5 text-xs font-bold text-gray-800">
                    <span className="text-rose-600">IPC</span>
                    <span>{inflacion.valor}%</span>
                 </div>
                 <span className="text-[10px] text-gray-400 mt-0.5">Última Inflación Mensual</span>
               </div>
            )}
        </div>
      </div>

      {/* Yields Container */}
      <div className="w-full bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
        <div className="h-9 bg-gray-50 border-b border-gray-200 flex items-center px-4 shrink-0">
           <TrendingUp className="w-4 h-4 text-indigo-600 mr-2" />
           <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wide">Rendimientos (TNA)</h2>
        </div>
        
        <div className="flex flex-col divide-y divide-gray-100">
            {/* Plazos Fijos Row */}
            <div className="flex items-center px-4 py-2 overflow-hidden h-12 relative group/pf">
                <span className="text-xs font-bold text-gray-500 uppercase shrink-0 mr-3 w-[100px]">Plazos Fijos:</span>
                
                <button 
                  onClick={() => scroll(pfScrollRef, 'left')}
                  className="absolute left-[105px] z-10 p-1.5 bg-white/95 border border-gray-200 rounded-full shadow-md text-gray-500 hover:text-blue-600 transition-all flex md:opacity-0 md:group-hover/pf:opacity-100"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                <div 
                  ref={pfScrollRef}
                  className="flex-1 flex items-center gap-4 overflow-x-auto no-scrollbar mask-gradient-right scroll-smooth px-2"
                >
                    {loading ? (
                        <div className="animate-pulse flex gap-4">
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                        </div>
                    ) : plazosFijos.length > 0 ? (
                        plazosFijos.map((item, i) => {
                            const cleanedName = cleanEntityName(item.entidad);
                            const url = getEntityUrl(cleanedName);
                            return (
                                <a 
                                    key={i} 
                                    href={url} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-1.5 group hover:bg-gray-50 px-2 py-1 rounded transition-colors shrink-0"
                                    title={`Ir a ${item.entidad}`}
                                >
                                    <span className="text-xs font-medium text-gray-800 whitespace-nowrap group-hover:text-blue-600 transition-colors">{cleanedName}</span>
                                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded-full">{(item.tna * 100).toFixed(1)}%</span>
                                </a>
                            );
                        })
                    ) : (
                        <p className="text-xs text-gray-400">No disponible</p>
                    )}
                </div>

                <button 
                  onClick={() => scroll(pfScrollRef, 'right')}
                  className="absolute right-1 z-10 p-1.5 bg-white/95 border border-gray-200 rounded-full shadow-md text-gray-500 hover:text-blue-600 transition-all flex md:opacity-0 md:group-hover/pf:opacity-100"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
            </div>

            {/* Billeteras Row */}
            <div className="flex items-center px-4 py-2 overflow-hidden h-12 relative group/bill">
                <span className="text-xs font-bold text-gray-500 uppercase shrink-0 mr-3 w-[100px]">Billeteras:</span>
                
                <button 
                  onClick={() => scroll(billScrollRef, 'left')}
                  className="absolute left-[105px] z-10 p-1.5 bg-white/95 border border-gray-200 rounded-full shadow-md text-gray-500 hover:text-green-600 transition-all flex md:opacity-0 md:group-hover/bill:opacity-100"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                <div 
                  ref={billScrollRef}
                  className="flex-1 flex items-center gap-4 overflow-x-auto no-scrollbar mask-gradient-right scroll-smooth px-2"
                >
                    {loading ? (
                        <div className="animate-pulse flex gap-4">
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                            <div className="h-4 bg-gray-100 rounded w-24"></div>
                        </div>
                    ) : billeteras.length > 0 ? (
                        billeteras.map((item, i) => {
                            const cleanedName = cleanEntityName(item.entidad);
                            const url = getEntityUrl(cleanedName);
                            return (
                                <a 
                                    key={i} 
                                    href={url} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-1.5 group hover:bg-gray-50 px-2 py-1 rounded transition-colors shrink-0"
                                    title={`Ir a ${item.entidad}`}
                                >
                                    <span className="text-xs font-medium text-gray-800 whitespace-nowrap group-hover:text-green-600 transition-colors">{cleanedName}</span>
                                    <span className="text-xs font-bold text-green-600 bg-green-50 px-1.5 py-0.5 rounded-full">{item.tna}%</span>
                                </a>
                            );
                        })
                    ) : (
                        <p className="text-xs text-gray-400">No disponible</p>
                    )}
                </div>

                <button 
                  onClick={() => scroll(billScrollRef, 'right')}
                  className="absolute right-1 z-10 p-1.5 bg-white/95 border border-gray-200 rounded-full shadow-md text-gray-500 hover:text-green-600 transition-all flex md:opacity-0 md:group-hover/bill:opacity-100"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
            </div>
        </div>
      </div>

      {/* News Container */}
      <div className="w-full h-[180px] bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
        {/* Container Header */}
        <div className="h-9 bg-gray-50 border-b border-gray-200 flex items-center justify-between px-4 shrink-0 overflow-x-auto no-scrollbar">
           <div className="flex items-center shrink-0 mr-4">
             <Newspaper className="w-4 h-4 text-blue-600 mr-2" />
             <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wide">Noticias</h2>
           </div>
        </div>

        {/* Horizontal Flex of Sources */}
        <div className="flex-1 flex flex-row divide-x divide-gray-100 overflow-hidden">
           {(Object.entries(groupedNews) as [string, NewsItem[]][]).map(([source, items]) => (
              <div key={source} className="flex-1 flex flex-col min-w-0 hover:bg-blue-50/30 transition-colors group/column relative">
                 {/* Source Header */}
                 <div className="py-1.5 px-1 text-center border-b border-gray-100 shrink-0 bg-white/50 backdrop-blur-sm">
                    <h3 className="font-bold text-[10px] text-gray-900 truncate w-full px-1" title={source}>
                      {source}
                    </h3>
                 </div>

                 {/* News List */}
                 <div className="flex-1 overflow-y-auto custom-scrollbar p-1.5">
                    {items.map((item, i) => {
                      const title = item.titulo || item.title || item.headline || 'Sin título';
                      const link = item.link || item.url || item.href;
                      
                      return (
                       <a 
                          key={i} 
                          href={link} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="block mb-2 last:mb-0 group/item"
                          title={title}
                       >
                          <p className="text-[9px] leading-snug text-gray-600 group-hover/column:text-gray-800 group-hover/item:text-blue-600 transition-colors line-clamp-3 font-medium">
                             {title}
                          </p>
                       </a>
                      );
                    })}
                 </div>
                 
                 {/* Count Badge */}
                 <div className="absolute top-1.5 right-1 w-1.5 h-1.5 rounded-full bg-blue-600/20 group-hover/column:bg-blue-600 transition-colors"></div>
              </div>
           ))}
        </div>
      </div>
    </div>
  );
}
